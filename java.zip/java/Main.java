public class Main {
    public static void main (String [] args) {
        int a = 5;

        Circulo c;
        c = new Circulo(); //criou o objeto circulo e guardou na variavel c.

        System.out.println ("raio (antes de declarar): " + c.raio);
        c.raio = 3.0;
        System.out.println ("raio (depois de declarar c): " + c.raio);


        Circulo c2;
        c2 = c;
        c2.raio = 6.0;
        System.out.println ("raio (depois de declarar c2): " + c2.raio);

        c2.imprimeArea();

        //como invocar um metodo: variavel.nomedometodo
        
    }

}