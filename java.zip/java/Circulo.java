public class Circulo {
    double raio; //<- Atributos
    
    double calculaArea() { //<- Método
        double area = 3.14 * this.raio * this.raio;
        return area;
    }

    void imprimeArea () { //<- Método
        double area = this.calculaArea(); //<- posso usar this. pois está se referindo ao método calculaArea
        System.out.println("Área: " + area); //<- nao poderia usar this.area, pois só se usa isso para atributos, e area é só uma variavel dentro do método
    }
}